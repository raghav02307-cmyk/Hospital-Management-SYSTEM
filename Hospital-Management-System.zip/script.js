﻿const navLinks = document.querySelectorAll(".nav-link");
const filterButtons = document.querySelectorAll(".filter");
const patientRows = document.querySelectorAll("tbody tr");

navLinks.forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.forEach((item) => item.classList.remove("active"));
    link.classList.add("active");
  });
});

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const filter = button.dataset.filter;
    filterButtons.forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    patientRows.forEach((row) => {
      const shouldShow = filter === "all" || row.dataset.status === filter;
      row.classList.toggle("hidden", !shouldShow);
    });
  });
});

﻿# MediCore Hospital Management System

Open `index.html` in any browser to view the website.

Files included:
- `index.html`
- `styles.css`
- `script.js`
